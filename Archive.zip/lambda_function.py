#import pymysql
#This is the connection to our content database AWS Relational database service
#try:
#    conn = pymysql.connect(host='utaechonews.coflj2xb1eul.us-east-1.rds.amazonaws.com', port=3306, user='kash_if47', passwd='HelloEcho2017', db='NewsDb')
#except:
#    print ("Error")
#
#cur = conn.cursor()

#Hard coded headlines just to test functionality

headlines = 'Pride Week to provide visibility, opportunities to community . . National Night Out to unite police, community . . Volleyball splits weekend in South Carolina . . UTA seeks new hires after freeze lifted . . McNair Scholars Program to accept new undergraduates . . Cross-country makes strides at 29th Annual Chile Pepper Festival . . Womens golf finishes 11th in third tournament.'

#This is the lambda function, the event parameter is the Jason request from which we will extract the intents.
def lambda_handler(event, context):
    # This is to check to make sure our app is the only skill that can access this lambda function
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")
    
    #Thus is where we return a response in JASON format to the Alexa skill speach output.
    response = {
        'version': '1.0',
        'response': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': headlines,
        }
    }
}
    #returning the response JASON structure
    return response
